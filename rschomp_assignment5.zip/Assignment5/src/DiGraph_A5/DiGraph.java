package DiGraph_A5;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Stack;
import java.util.ArrayList;
public class DiGraph implements DiGraphInterface {

  // in here go all your data and methods for the graph
  // and the topo sort operation
  private List<String>edgeStrings;
  HashMap<String, Vertex> hm;
  HashSet<Long>edgeInfo, vertexInfo;
  public long countVertex;
  public long countEdges;
  public Vertex vertexArray[];
  //private HashMap<String, List<String>> hm2;
  //private ArrayList<List<Node>> adList;
	
  public DiGraph ( ) { // default constructor
	  this.edgeStrings = new ArrayList<String>();
	  this.hm = new HashMap<String, Vertex>();
	  this.edgeInfo = new HashSet<Long>();
	  this.vertexInfo = new HashSet<Long>();
	  countVertex = 0;
	  countEdges = 0;
	  vertexArray = new Vertex[1000];
	  
	 // hm = new HashMap<Long, String>();
	 // hm2 = new HashMap<String, List<String>>();
	  // explicitly include this
    // we need to have the default constructor
    // if you then write others, this one will still be there
  }
  
@Override
public boolean addNode(long idNum, String label) {
	
	if (idNum < 0 ){
		return false;
	}
	if(label == null){
		return false;
	}
	if(vertexInfo.contains(idNum)){
		return false;
	}
	if(hm.containsKey(label)){
		return false;
	}
		Vertex vertex = new Vertex(idNum, label); //creating a new node
		vertexInfo.add(idNum); //add info about node to hashset
		vertexArray[(int) idNum] = vertex; //put that vertex in array for queing in topo
		hm.put(label, vertex); //put vertex in hashmap
		countVertex++; //upcount
		return true;

}

@Override
public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
	String conForAdd = sLabel+dLabel;
	
	if(edgeInfo.contains(idNum) == true){
		return false;
	}
	else if(idNum < 0){
		return false;
	}
	else if(hm.containsKey(sLabel) == false){
		return false;
	}
	else if(hm.containsKey(dLabel) == false){
		return false;
	}
	else if(edgeStrings.contains(conForAdd)){
		return false;
	}
	
	else {
	Edge edge = new Edge (idNum, 1, eLabel); //make weight 1 for this assignment
	edge.nextEdge = hm.get(sLabel).theEdge;
	hm.get(sLabel).theEdge = edge;
	edge.thisVertex = hm.get(dLabel);
	
	edgeStrings.add(conForAdd);
	
	hm.get(dLabel).inArrows++;//you have another arrow coming in
	hm.get(sLabel).outArrows++;//you have another arrow going out
	edgeInfo.add(idNum);
	countEdges++;

	return true;
	}
}
	

/*
	if(edgeStrings.contains(conOne)){
		//edge already made
		return false;
	}
	else if (numNodes < 2){
		return false;
	}
	else if (idNum < 0){
		return false;
	}
	else if (!vertices.containsKey(sLabel) || !vertices.containsKey(dLabel)){
		return false;
	}
	else if(edge_ids.contains(idNum)){
		return false;
	}
	else{
		Vertex fromVertex = vertices.get(sLabel);
		Vertex toVertex = vertices.get(dLabel);
		Edge newEdge = new Edge(idNum, fromVertex, toVertex, weight, eLabel);
		edgeStrings.add(conOne);
		edgeStrings.add(conTwo);
		
	}
	return false;
}
*/
@Override
public boolean delNode(String label) {
	if(hm.containsKey(label) == false){
		return false;
	}
	for (int i = 0; i <= vertexArray.length-1; i++){
		if(vertexArray[i] != null){
			this.delEdge(vertexArray[i].label, label);
		}
	}
	
	Vertex vertex = hm.get(label);//get it first
	hm.remove(label);//now you can remove it
	vertexArray[(int) vertex.idNum] = null;
	vertexInfo.remove(vertex.idNum);
	countVertex--;
	
	return true;
}
	

@Override
public boolean delEdge(String sLabel, String dLabel) {
	String conForDel = sLabel+dLabel;
	
	if(hm.containsKey(sLabel) == false){
		return false;
	}
	else if(hm.containsKey(dLabel) == false){
		return false;
	}	
	else if(hm.get(sLabel) == null){
		return false;
	}
	else if(hm.get(dLabel) == null){
		return false;
	}
	
	else if(!edgeStrings.contains(conForDel)){
		return false;
	}
	else {
	Edge priorEdge = null;
	Edge tempEdge = hm.get(sLabel).theEdge;
	
	edgeStrings.remove(conForDel);
	
	while(tempEdge != null){
		if(hm.get(dLabel) != tempEdge.thisVertex){
			priorEdge = tempEdge;
			tempEdge = tempEdge.nextEdge;
		}
		else{
			if(priorEdge != null){
				priorEdge.nextEdge = tempEdge.nextEdge;
			}
			else{
				hm.get(sLabel).theEdge = tempEdge.nextEdge;
			}
			edgeInfo.remove(tempEdge.idNum);
			hm.get(dLabel).inArrows--;
			hm.get(sLabel).outArrows--;
			countEdges--;
			return true;
		}
		
	}
	return false;
	}
}


@Override
public long numNodes() {
	// TODO Auto-generated method stub
	return countVertex;
}

@Override
public long numEdges() {
	// TODO Auto-generated method stub
	return countEdges;
}
int i = 0;
@Override
public String[] topoSort() {
	int counter = 0;
	Edge newerEdge;
	String fn, tn;
	int integer = 0;
	String[] topoArray = new String[10000];
	Stack<String> queue = new Stack<String>();
	Stack<String> extraQueue = new Stack<String>();
	
	for(i = 0; i <= vertexArray.length-1; i++){
		if(vertexArray[i] == null || vertexArray[i].inArrows != 0){	//nothing in array or has in arrows, dont start here
		}
		else{
			queue.push(vertexArray[i].label);//push onto stack
		}
	}
	
	while(queue.size() != 0){
		fn = queue.pop();
		topoArray[counter] = fn;
		newerEdge = this.vertexArray[(int) hm.get(fn).idNum].theEdge;
		counter++;
		
		while(newerEdge != null){
			extraQueue.push(newerEdge.thisVertex.label);
			newerEdge = newerEdge.nextEdge;
		}
		
		while(extraQueue.size() > 0){
			tn = extraQueue.pop();
			this.delEdge(fn, tn);
			if(this.hm.get(tn).inArrows == 0){
				queue.push(tn);
			}
		}
	}
	
	for(i = 0; i <= topoArray.length-1; i++){
		if(topoArray[i] != null){
			integer++;
		}
	}
	
	if(integer != this.countVertex){
		return null;
	}
	else {
		String[] copy = new String[integer];
		for(i = 0; i <= integer-1; i++){
			copy[i] = topoArray[i];
		}
		return copy;
	}
}
}