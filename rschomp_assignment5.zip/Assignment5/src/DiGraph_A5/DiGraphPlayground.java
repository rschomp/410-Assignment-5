package DiGraph_A5;

public class DiGraphPlayground {

  public static void main (String[] args) {
  
      // thorough testing is your responsibility
      //
      // you may wish to create methods like 
      //    -- print
      //    -- sort
      //    -- random fill
      //    -- etc.
      // in order to convince yourself your code is producing
      // the correct behavior
    exTest();
    }
  
    public static void exTest(){
      DiGraph d = new DiGraph();
      d.addNode(1, "f");
      d.addNode(3, "s");
      d.addNode(7, "t");
      d.addNode(0, "fo");
      d.addNode(4, "fi");
      d.addNode(6, "si");
      d.addEdge(0, "f", "s", 0, null);
      d.addEdge(1, "f", "si", 0, null);
      d.addEdge(2, "s", "t", 0, null);
      d.addEdge(3, "fo", "fi", 0, null);
      d.addEdge(4, "fi", "si", 0, null);
      System.out.println("numEdges: "+d.numEdges());
      System.out.println("numNodes: "+d.numNodes());
      printTOPO(d.topoSort());
      
      DiGraph f = new DiGraph();
      f.addNode(0, "4");
      f.addNode(1, "1");
      f.addNode(2, "8");
      f.addNode(3, "2");
      f.addNode(4, "7");
      f.addNode(5, "5");
      f.addEdge(0, "2", "5", 0, null);
      f.addEdge(1, "4", "7", 0, null);
      f.addEdge(2, "1", "8", 0, null);
      f.addEdge(3, "2", "8", 0, null);
      f.addEdge(4, "4", "5", 0, null);
      f.addEdge(5, "1", "2", 0, null);
      f.addEdge(6, "1", "5", 0, null);
      f.addEdge(7, "1", "7", 0, null);
      f.addEdge(8, "8", "5", 0, null);
      f.addEdge(9, "1", "4", 0, null);
      f.addEdge(10, "5", "7", 0, null);
      f.addEdge(11, "4", "2", 0, null);
      f.addEdge(12, "8", "7", 0, null);
      f.addEdge(13, "4", "8", 0, null);
      f.addEdge(14, "2", "7", 0, null);
      
      //ind(1) < ind(4) < ind(2) < ind(8) < ind(5) < ind(7);
      
    }
    public static void printTOPO(String[] toPrint){
      System.out.print("TOPO Sort: ");
      for (String string : toPrint) {
      System.out.print(string+" ");
    }
      System.out.println();
    }

}

