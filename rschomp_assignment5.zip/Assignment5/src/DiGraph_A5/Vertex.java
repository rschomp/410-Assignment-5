package DiGraph_A5;

//import java.util.HashMap;

public class Vertex {

	long idNum;
	String label;
	int inArrows = 0;
	int outArrows = 0;
	Edge theEdge;
	
	public Vertex(long idNum, String label){

		this.idNum = idNum;
		this.label = label;
		this.theEdge = null;
	}

}
