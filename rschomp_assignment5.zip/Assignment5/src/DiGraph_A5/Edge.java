package DiGraph_A5;

public class Edge {
	String elabel;
	long idNum;
	long weight;
	Vertex thisVertex;
	Edge nextEdge;
	
	public Edge(long idNum, long weight, String elabel){ 
		this.idNum = idNum;
		this.weight = weight;
		this.elabel = elabel;
		this.thisVertex = null;
		this.nextEdge = null;
	}
	
}
